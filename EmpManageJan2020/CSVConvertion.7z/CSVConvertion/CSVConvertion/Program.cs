﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Dynamic;
using System.Linq.Dynamic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using CsvHelper;
using System.IO;
using System.Globalization;
using System.Management.Instrumentation;
using Microsoft.VisualBasic.FileIO;
using System.Data;
using Newtonsoft.Json;
using NLog;

namespace CSVConvertion
{
    internal class Program
    {
        private static Logger logger = LogManager.GetCurrentClassLogger();

        private static void Main(string[] args)
        {
            DateTime startTime = DateTime.Now;

            logger.Info("CSV File Updation Started at : " + startTime.ToString());

            Console.WriteLine(startTime.ToString());

            char[] configDelimiters = { ',' };
            char[] fileDelimiters;

            List<string> config = new List<string>();

            List<string> keyValues = new List<string>();
            List<string> updateValues = new List<string>();

            List<string> keyValuesFinal = new List<string>();
            List<string> updateValuesFinal = new List<string>();

            using (var rd = new StreamReader("config.csv"))
            {
                while (!rd.EndOfStream)
                {
                    //if (!string.IsNullOrEmpty(rd.ReadLine().Trim()))
                    //{
                    config.Add(rd.ReadLine().Trim());
                    //}
                }
            }

            string sourceFileName = config[0].Split(',')[1].Trim();
            logger.Info("Source File Full Path : " + sourceFileName);

            config.RemoveAt(0);

            string delimiter = config[0].Split(',')[1].Trim();
            logger.Info("Delimiter Config : " + delimiter);

            config.RemoveAt(0);

            config.RemoveAt(0); //Remove row KeyColumns

            //Get Index of UpdateColumns

            int updateColumnsIndex = config.IndexOf("UpdateColumns");

            keyValues = config.Take(updateColumnsIndex).ToList();
            logger.Info("Key value to search count : " + keyValues.Count.ToString());

            config.RemoveRange(0, updateColumnsIndex);

            config.RemoveAt(0); //Remove row UpdateColumns

            updateValues = config;
            logger.Info("Update Values to search count : " + updateValues.Count.ToString());

            if (updateValues.Count != keyValues.Count)
            {
                Console.WriteLine("updateValues.Count and keyValues.Count mismatch");
                logger.Info("updateValues.Count and keyValues.Count mismatch. Process ending");
                return;
            }

            logger.Info("");

            keyValues.ForEach(x =>
                    {
                        string trimmed = x.Substring(x.IndexOf(',') + 1);
                        keyValuesFinal.Add(trimmed);

                        logger.Info(trimmed);
                    }
            );

            logger.Info("");

            updateValues.ForEach(x =>
            {
                string trimmed = x.Substring(x.IndexOf(',') + 1);
                updateValuesFinal.Add(trimmed);

                logger.Info(trimmed);
            }
           );

            logger.Info("");

            ConfigToExpandoObject configToExpandoObject = new ConfigToExpandoObject();

            List<ExpandoObject> keyFieldsExpandoObject = configToExpandoObject
                                                            .ExtractStringToExpandoObject(keyValuesFinal, configDelimiters);

            List<ExpandoObject> updateFieldsExpandoObject = configToExpandoObject
                                                           .ExtractStringToExpandoObject(updateValuesFinal, configDelimiters);

            if (delimiter == "comma")
            {
                char[] delimitersComma = { ',' };

                fileDelimiters = delimitersComma;
            }
            else
            {
                char[] delimitersComma = { ',' };

                fileDelimiters = delimitersComma;
            }

            FileToExpandoObject fileToExpandoObject = new FileToExpandoObject();

            logger.Info("Started CSV to ExpandoObject at : " + DateTime.Now.ToString());
            DateTime csvDataExtractStartTime = DateTime.Now;

            List<ExpandoObject> csvDataExtract = fileToExpandoObject.LoadCSV(sourceFileName, fileDelimiters);

            logger.Info("Completed CSV to ExpandoObject at : "
                    + DateTime.Now.ToString() + " | "
                    + "Total rows conveted " + csvDataExtract.Count + " | "
                    + ((decimal)DateTime.Now.Subtract(csvDataExtractStartTime).TotalMinutes).ToString("n2")
                         + " Minutes or "
                    + (int)DateTime.Now.Subtract(csvDataExtractStartTime).TotalSeconds + " Seconds");

            logger.Info("");

            logger.Info("Started ExpandoObject To Datatable at : " + DateTime.Now.ToString());
            DateTime csvDataExtractDataTableStartTime = DateTime.Now;

            var csvDataExtractDataTable = ConvertToDataTable(csvDataExtract);

            logger.Info("Completed ExpandoObject To Datatable at : "
                + DateTime.Now.ToString() + " | "
                + "Total rows conveted " + csvDataExtract.Count + " | "
                + ((decimal)DateTime.Now.Subtract(csvDataExtractDataTableStartTime).TotalMinutes).ToString("n2")
                     + " Minutes or "
                + (int)DateTime.Now.Subtract(csvDataExtractDataTableStartTime).TotalSeconds + " Seconds");

            List<string> datatableQuerys = new List<string>();

            logger.Info("");
            logger.Info("Building Search Queries");

            foreach (var item in keyFieldsExpandoObject)
            {
                string queryBuild = "";

                IDictionary<string, object> keyFieldsExpandoObjectPrp = item;

                foreach (var property in keyFieldsExpandoObjectPrp.Keys)
                {
                    if (queryBuild != "")
                    {
                        queryBuild = queryBuild + " AND";
                    }

                    queryBuild = queryBuild + " [" + property + "] = '"
                                        + keyFieldsExpandoObjectPrp[property] + "'";
                }

                logger.Info(queryBuild);

                datatableQuerys.Add(queryBuild);
            }

            logger.Info("");

            int index = 0;

            logger.Info("Started Search and Update datatable at : " + DateTime.Now.ToString());
            DateTime searchAndUpdateStartTime = DateTime.Now;

            for (int i = 0; i < datatableQuerys.Count; i++)
            {
                DataRow result1 = csvDataExtractDataTable.Select(datatableQuerys[i]).FirstOrDefault();
                index = csvDataExtractDataTable.Rows.IndexOf(result1);

                string rowUpdationLog = string.Empty;

                if (index >= 0)
                {
                    var finalResultToInsert = updateFieldsExpandoObject[i] as IDictionary<string, object>;

                    foreach (var property in finalResultToInsert.Keys)
                    {
                        csvDataExtractDataTable.Rows[index][property] = finalResultToInsert[property];
                    }

                    rowUpdationLog = "Found Key field for combination " + keyValues[i + 1]
                                        + " & Updated line at " + (index + 2).ToString();
                }
                else
                {
                    rowUpdationLog = "Not Foud Key field for combination " + keyValues[i + 1];
                }

                logger.Info(rowUpdationLog);
            }

            logger.Info("Completed Search and Update Datatable at : "
              + DateTime.Now.ToString() + " | "
              + "Total rows conveted " + csvDataExtract.Count + " | "
              + ((decimal)DateTime.Now.Subtract(searchAndUpdateStartTime).TotalMinutes).ToString("n2")
                   + " Minutes or "
              + (int)DateTime.Now.Subtract(searchAndUpdateStartTime).TotalSeconds + " Seconds");

            FileInfo info = new FileInfo(sourceFileName);
            string newFileName = info.DirectoryName + @"\"
                                  + Path.GetFileNameWithoutExtension(info.Name)
                                    + "_up."
                                    + Path.GetExtension(info.Name);

            logger.Info("");

            logger.Info("New CSV File Name : " + newFileName);

            logger.Info("Started datatable to CSV at : " + DateTime.Now.ToString());
            DateTime datatableToCSV = DateTime.Now;

            ToCSV(csvDataExtractDataTable, newFileName, fileDelimiters);

            logger.Info("Completed datatable to CSV at : "
            + DateTime.Now.ToString() + " | "
            + "Total rows conveted " + csvDataExtract.Count + " | "
            + ((decimal)DateTime.Now.Subtract(datatableToCSV).TotalMinutes).ToString("n2")
                 + " Minutes or "
            + (int)DateTime.Now.Subtract(datatableToCSV).TotalSeconds + " Seconds");

            logger.Info("CSV File Updation Completed at : "
           + DateTime.Now.ToString() + " | "
           + ((decimal)DateTime.Now.Subtract(startTime).TotalMinutes).ToString("n2")
                + " Minutes or "
           + (int)DateTime.Now.Subtract(startTime).TotalSeconds + " Seconds");

            Console.WriteLine("Updation Done. Please enter any keys to shutdown");

            Console.ReadLine();
        }

        public static DataTable ConvertToDataTable<T>(IEnumerable<T> data)
        {
            DataTable table = new DataTable();
            foreach (T item in data)
            {
                if (item is IDictionary<string, object> dict)
                {
                    foreach (var key in dict)
                    {
                        table.Columns.Add(key.Key, key.Value?.GetType() ?? typeof(object));
                    }
                    break;
                }
                foreach (var prop in typeof(T).GetProperties())
                {
                    table.Columns.Add(prop.Name, prop.PropertyType);
                }
                break;
            }

            DataRow row = null;
            foreach (T item in data)
            {
                if (item is IDictionary<string, object> dict)
                {
                    row = table.NewRow();
                    foreach (var key in dict)
                    {
                        row[key.Key] = key.Value;
                    }
                    table.Rows.Add(row);
                    continue;
                }

                row = table.NewRow();
                foreach (var prop in typeof(T).GetProperties())
                {
                    row[prop.Name] = prop.GetValue(item);
                }
                table.Rows.Add(row);
            }
            return table;
        }

        public static void ToCSV(DataTable dtDataTable, string strFilePath, char[] fileDelimiters)
        {
            string delimiter = fileDelimiters[0].ToString();

            StreamWriter sw = new StreamWriter(strFilePath, false);
            //headers
            for (int i = 0; i < dtDataTable.Columns.Count; i++)
            {
                sw.Write(dtDataTable.Columns[i]);
                if (i < dtDataTable.Columns.Count - 1)
                {
                    sw.Write(delimiter);
                }
            }

            foreach (DataRow dr in dtDataTable.Rows)
            {
                sw.Write(sw.NewLine);

                for (int i = 0; i < dtDataTable.Columns.Count; i++)
                {
                    if (!Convert.IsDBNull(dr[i]))
                    {
                        string value = dr[i].ToString();
                        if (value.Contains(','))
                        {
                            value = String.Format("\"{0}\"", value);
                            sw.Write(value);
                        }
                        else
                        {
                            sw.Write(dr[i].ToString());
                        }
                    }
                    if (i < dtDataTable.Columns.Count - 1)
                    {
                        sw.Write(delimiter);
                    }
                }
            }
            sw.Close();
        }
    }
}
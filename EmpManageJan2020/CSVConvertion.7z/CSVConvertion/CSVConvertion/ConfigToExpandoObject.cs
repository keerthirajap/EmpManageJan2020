﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Dynamic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSVConvertion
{
    /// <summary>
    /// Class which is used read the CSV file of acronyms
    /// </summary>
    internal class ConfigToExpandoObject
    {
        /// <summary>
        /// List of expando object created
        /// </summary>
        private List<ExpandoObject> loadedAcronyms;

        /// <summary>
        /// Default constructor
        /// </summary>
        public ConfigToExpandoObject()
        {
        }

        /// <summary>
        /// Method reads the filename as a CSV file, and creates the List of ExpandObjects
        /// </summary>
        /// <param name="fileName">File of CSV to be read</param>
        /// <returns>List of ExpandoObject, one object for each line in the CSV file</returns>
        internal List<ExpandoObject> ExtractStringToExpandoObject(List<string> keyValuesFinal, char[] delimiters)
        {
            List<string> Fields = ReadHeader(keyValuesFinal[0], delimiters);
            keyValuesFinal.RemoveAt(0);
            loadedAcronyms = ReadFileData(keyValuesFinal, Fields, delimiters);
            Debug.WriteLine(loadedAcronyms.Count);
            return loadedAcronyms;
        }

        /// <summary>
        /// Reads the data file of CSV.
        /// Skips the first line, as that has the header row.
        /// Very simple file read and parse the CSV.
        /// </summary>
        /// <param name="fileName">File of CSV to be read</param>
        /// <param name="Fields">The Header Row parsed to identify the columns</param>
        /// <returns>List of ExpandoObject, one object for each line in the CSV file</returns>
        private List<ExpandoObject> ReadFileData(List<string> keyValuesFinal, List<string> Fields, char[] delimiters)
        {
            List<ExpandoObject> result = new List<ExpandoObject>();

            foreach (var line in keyValuesFinal)
            {
                string[] tokens = line.Split(delimiters);
                dynamic add = new ExpandoObject();
                for (int i = 0; i < tokens.Length; i++)
                {
                    if (i >= Fields.Count())
                        continue;

                    ((IDictionary<string, object>)add).Add(new KeyValuePair<string, object>(Fields[i], tokens[i]));
                    // Demonstrates, in a limited context that a Dynamic Object "plays"
                    //  plays like a real object with dynamically added properties.
                }
                result.Add(add);
            }

            return result;
        }

        /// <summary>
        /// Reads the header line from a CSV file, and use that line as the field names for reading that file.
        /// </summary>
        /// <param name="fileName">Filename of the CSV to be read</param>
        /// <returns>List of strings, one string for each column in the header record</returns>
        private List<string> ReadHeader(string header, char[] delimiters)
        {
            return header.Split(delimiters, StringSplitOptions.RemoveEmptyEntries).Select(A => A.Trim()).ToList();
        }
    }
}